/**
 * main.ts
 *
 * Purpose:
 * - run the B-plan minimum support set
 * - inspect coordinator selection
 * - execute runtime and engine flows
 * - print readable output for first verification
 */

import type {
  SupportRequest,
} from "./support/core/support_interface.js";

import {
  coordinateSupport,
} from "./support/registry/support_coordinator.js";

import {
  runSupportRequest,
} from "./support/runtime/support_runtime.js";

import {
  runSupportEngine,
} from "./support/runtime/support_engine.js";

import {
  listSupportTraceEntries,
  clearSupportTraceStore,
} from "./support/trace/support_trace.js";

import {
  listSupportEngineTraceEntries,
  clearSupportEngineTraceStore,
} from "./support/trace/support_engine_trace.js";

function createValidationRequest(): SupportRequest {
  const requestId = "req-validation-001";

  return {
    requestId,
    rootRequestId: requestId,
    requesterId: "system",
    requestType: "validation",
    urgency: "degraded",
    automatic: false,
    allowReserve: false,
    reason: "Structural uncertainty remains visible after recent degradation.",
    contextNotes:
      "Validation should expose unresolved weak points without overstating recovery.",
  };
}

function createRepairRequest(): SupportRequest {
  const requestId = "req-repair-001";

  return {
    requestId,
    rootRequestId: requestId,
    requesterId: "system",
    requestType: "repair",
    urgency: "degraded",
    automatic: false,
    allowReserve: false,
    reason: "Known repair debt should be handled conservatively.",
    contextNotes:
      "Repair should stay bounded and avoid broad restructuring.",
  };
}

function createReentryRequest(): SupportRequest {
  const requestId = "req-reentry-001";

  return {
    requestId,
    rootRequestId: requestId,
    requesterId: "system",
    requestType: "reentry",
    urgency: "normal",
    automatic: true,
    allowReserve: false,
    reason: "A guarded return to the active path is needed.",
    contextNotes:
      "Reentry should remain narrow and supervised until later validation or repair confirms stability.",
  };
}

function printDivider(title: string): void {
  console.log("");
  console.log("=".repeat(72));
  console.log(title);
  console.log("=".repeat(72));
}

function printCoordinatorPreview(request: SupportRequest): void {
  const coordination = coordinateSupport(request);

  console.log("[Coordinator]");
  console.log("requestId:", request.requestId);
  console.log("requestType:", request.requestType);
  console.log("matchedCapability:", coordination.matchedCapability ?? "none");
  console.log("accepted:", coordination.accepted);
  console.log("selectedNode:", coordination.selectedNode?.supportNodeId ?? "none");
  console.log("selectedRole:", coordination.selectedNode?.role ?? "none");
  console.log("warnings:", coordination.warnings);
}

function printRuntimeResult(request: SupportRequest): void {
  const runtimeResult = runSupportRequest(request, {
    persistTraceToFile: true,
  });

  console.log("[Runtime]");
  console.log("executed:", runtimeResult.executed);
  console.log("selectedNodeId:", runtimeResult.selectedNodeId ?? "none");
  console.log("matchedCapability:", runtimeResult.matchedCapability ?? "none");
  console.log("responderId:", runtimeResult.response.responderId);
  console.log("accepted:", runtimeResult.response.accepted);
  console.log("followUpNeeded:", runtimeResult.response.followUpNeeded === true);
  console.log("actionSummary:", runtimeResult.response.actionSummary);
  console.log("warnings:", runtimeResult.response.warnings);
}

function printEngineResult(request: SupportRequest): void {
  const engineResult = runSupportEngine(request, {
    maxSteps: 2,
    persistEngineTraceToFile: true,
  });

  console.log("[Engine]");
  console.log("ok:", engineResult.ok);
  console.log("stepCount:", engineResult.steps.length);
  console.log("stoppedBecause:", engineResult.stoppedBecause);
  console.log("finalResponderId:", engineResult.finalResponse.responderId);
  console.log("finalAccepted:", engineResult.finalResponse.accepted);
  console.log("finalFollowUpNeeded:", engineResult.finalResponse.followUpNeeded === true);
  console.log("finalActionSummary:", engineResult.finalResponse.actionSummary);
  console.log("finalWarnings:", engineResult.finalResponse.warnings);

  if (engineResult.steps.length > 0) {
    console.log("[Engine Steps]");
    for (const step of engineResult.steps) {
      console.log(
        `- step=${step.stepIndex}, requestId=${step.request.requestId}, root=${step.request.rootRequestId ?? step.request.requestId}, parent=${step.request.parentRequestId ?? "none"}, responder=${step.execution.response.responderId}, accepted=${step.execution.response.accepted}`,
      );
    }
  }
}

function printTraceSummary(): void {
  const runtimeTraceEntries = listSupportTraceEntries();
  const engineTraceEntries = listSupportEngineTraceEntries();

  console.log("[Trace Summary]");
  console.log("runtimeTraceCount:", runtimeTraceEntries.length);
  console.log("engineTraceCount:", engineTraceEntries.length);

  const latestRuntime = runtimeTraceEntries[runtimeTraceEntries.length - 1];
  const latestEngine = engineTraceEntries[engineTraceEntries.length - 1];

  if (latestRuntime) {
    console.log("latestRuntimeTrace:", {
      requestId: latestRuntime.requestId,
      rootRequestId: latestRuntime.rootRequestId,
      parentRequestId: latestRuntime.parentRequestId,
      stage: latestRuntime.stage,
    });
  }

  if (latestEngine) {
    console.log("latestEngineTrace:", {
      requestId: latestEngine.requestId,
      rootRequestId: latestEngine.rootRequestId,
      parentRequestId: latestEngine.parentRequestId,
      stage: latestEngine.stage,
      stoppedBecause: latestEngine.stoppedBecause,
    });
  }
}

function runScenario(title: string, request: SupportRequest): void {
  printDivider(title);
  printCoordinatorPreview(request);
  console.log("");
  printRuntimeResult(request);
  console.log("");
  printEngineResult(request);
  console.log("");
  printTraceSummary();
}

function resetTraceStores(): void {
  clearSupportTraceStore();
  clearSupportEngineTraceStore();
}

function main(): void {
  resetTraceStores();

  runScenario("SCENARIO 1: VALIDATION", createValidationRequest());
  runScenario("SCENARIO 2: REPAIR", createRepairRequest());
  runScenario("SCENARIO 3: REENTRY", createReentryRequest());
}

main();
